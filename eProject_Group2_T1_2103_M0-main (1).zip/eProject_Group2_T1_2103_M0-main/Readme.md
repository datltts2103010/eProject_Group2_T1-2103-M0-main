There are links of our e-project:

Link website: https://tommylam0402.github.io/eProject_Group2_T1_2103_M0/

Link github: https://github.com/tommylam0402/eProject_Group2_T1_2103_M0

Link e-project document report: https://github.com/tommylam0402/eProject_Group2_T1_2103_M0/blob/main/eProject_Group2_T1-2103-M0-main.pdf

Thank you for watching our e-project.
